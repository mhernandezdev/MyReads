import React, { Component } from 'react';
import { Link } from 'react-router-dom'
import PropTypes from 'prop-types'
import sortBy from 'sort-by'

class BookShelf extends Component {
    static propTypes = {
        books: PropTypes.array.isRequired,
    }

    state = {
        query: ''
    }

    updateQuery = (query) => {
        this.setState({ query: query.trim() })
    }

    clearQuery = () => {
        this.setState({ query: '' })
    }

    render() {
        const { books, onDeleteContact } = this.props
        const { query } = this.state

        let showingBooks
        if (query) {
            /*const match = new RegExp(escapeRegExp(query), 'i')
            showingContacts = contacts.filter((contact) => match.test(contact.name))*/
        } else {
            showingBooks = books
        }

        showingBooks.sort(sortBy('name'))
        console.log("showingBooks", showingBooks)
        let currentShelf = "";

        return (
            <div>


                    {showingBooks.map((book) => {
                        return (
                            <div key{book.name} className="F"></div>
                            {/*book.shelf!==currentShelf ?
                                <div className="bookshelf">
                                <h2 className="bookshelf-title">{book.shelf}</h2>
                                <div className="bookshelf-books">
                                    <ol className="books-grid">
                            : null*/}





                                {/*<li key={contact.id} className='book'>
                                <div className='contact-avatar' style={{
                                    backgroundImage: `url(${contact.avatarURL})`
                                }}/>
                                <div className='contact-details'>
                                    <p>{contact.name}</p>
                                    <p>{contact.email}</p>
                                </div>
                                <button onClick={() => onDeleteContact(contact)} className='contact-remove'>
                                    Remove
                                </button>
                            </li>*/}


                                <li>
                                    <div key={book.id} className="book">
                                        <div className="book-top">
                                            <div className="book-cover" style={{ width: 128, height: 193, backgroundImage: `url(${book.imageLinks.thumbnail})` }}></div>
                                            <div className="book-shelf-changer">
                                                <select>
                                                    <option value="none" disabled>Move to...</option>
                                                    <option value="currentlyReading">Currently Reading</option>
                                                    <option value="wantToRead">Want to Read</option>
                                                    <option value="read">Read</option>
                                                    <option value="none">None</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div className="book-title">{book.title}</div>
                                        <div className="book-authors">{book.authors}</div>
                                    </div>
                                </li>

                            {book.shelf !== currentShelf ?
                                    </ol>
                                </div>
                            </div>
                            : null}
                        )
                })}
            </div>
        )
    }
}

export default BookShelf
